
import {
    app,
    auth,
    database,
    signOut,
    onAuthStateChanged,
    ref,
    push,
    set,
    get,
    onValue,
    getMessaging,
    isSupported,
    getToken,
    onMessage
} from "./firebase.js";

const userData = JSON.parse(sessionStorage.getItem("user") || "null");

const userName = document.getElementById("userName");
const userEmail = document.getElementById("userEmail");
const userList = document.getElementById("userList");
const chatTitle = document.getElementById("chatTitle");
const messageArea = document.getElementById("messageArea");
const messageForm = document.getElementById("messageForm");
const messageInput = document.getElementById("messageInput");
const logoutButton = document.getElementById("logoutButton");

const enableNotificationButton =
    document.getElementById("enableNotificationButton");

const notificationStatus =
    document.getElementById("notificationStatus");

const VAPID_KEY = "BEfMce8SXLl3WkNQ9n8tleaxPGWuzqujyEeOoWcN925zz5KQPhmN40FisGZ3kCT9YKgEB6KoIAJ6I0RCOq875FE";

let selectedUser = null;
let currentConversationId = null;
let stopMessageListener = null;
let currentFirebaseUser = null;
let foregroundListenerInitialized = false;

if (!userData) {
    window.location.href = "login.html";
}

if (userData) {
    userName.textContent = userData.name || "Pengguna";
    userEmail.textContent = userData.email || "";
}

function showError(message) {
    alert(message);
}

function formatTime(timestamp) {
    if (!timestamp) return "";

    return new Date(timestamp).toLocaleTimeString("id-ID", {
        hour: "2-digit",
        minute: "2-digit"
    });
}

// Mengaktifkan notifikasi browser
async function enableNotifications() {
    try {
        if (!("Notification" in window)) {
            throw new Error("Browser tidak mendukung notifikasi.");
        }

        if (!("serviceWorker" in navigator)) {
            throw new Error("Browser tidak mendukung Service Worker.");
        }

        if (!VAPID_KEY || VAPID_KEY === "TEMPEL_VAPID_KEY_DI_SINI") {
            throw new Error("VAPID Key belum dimasukkan ke dashboard.js.");
        }

        const supported = await isSupported();

        if (!supported) {
            throw new Error("Firebase Messaging tidak didukung browser ini.");
        }

        notificationStatus.textContent =
            "Meminta izin notifikasi...";

        const permission = await Notification.requestPermission();

        if (permission !== "granted") {
            notificationStatus.textContent =
                "Izin notifikasi belum diberikan.";
            return;
        }

        notificationStatus.textContent =
            "Mendaftarkan perangkat...";

        // Daftarkan Service Worker
        const serviceWorkerRegistration =
            await navigator.serviceWorker.register(
                "./firebase-messaging-sw.js",
                {
                    scope: "./"
                }
            );

        notificationStatus.textContent =
            "Menunggu Service Worker aktif...";

        // Tunggu sampai Service Worker aktif
        const activeRegistration =
            await navigator.serviceWorker.ready;

        if (!activeRegistration.active) {
            throw new Error(
                "Service Worker belum berhasil diaktifkan."
            );
        }

        const messaging = getMessaging(app);

        // Mengambil FCM Token setelah Service Worker aktif
        const token = await getToken(messaging, {
            vapidKey: VAPID_KEY,
            serviceWorkerRegistration: activeRegistration
        });

        if (!token) {
            throw new Error("Firebase gagal menghasilkan FCM Token.");
        }

        notificationStatus.textContent =
            "Menyimpan token notifikasi...";

        // Simpan token ke database MySQL
        const response = await fetch(
            "../backend/api/save_fcm_token.php",
            {
                method: "POST",
                credentials: "same-origin",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    token: token
                })
            }
        );

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(
                result.message || "Gagal menyimpan token notifikasi."
            );
        }

        notificationStatus.textContent =
            "Notifikasi berhasil diaktifkan!";

        enableNotificationButton.textContent =
            "Notifikasi Aktif";

        enableNotificationButton.disabled = true;

        setupForegroundNotifications(messaging);

    } catch (error) {
        console.error("Aktivasi notifikasi:", error);

        notificationStatus.textContent =
            "Gagal mengaktifkan notifikasi: " + error.message;
    }
}

// Menampilkan notifikasi ketika dashboard sedang terbuka
function setupForegroundNotifications(messaging) {
    if (foregroundListenerInitialized) return;

    foregroundListenerInitialized = true;

    onMessage(messaging, payload => {
        const title =
            payload.notification?.title || "Web Chat CPK";

        const body =
            payload.notification?.body || "Kamu menerima pesan baru.";

        if (Notification.permission === "granted") {
            new Notification(title, {
                body: body
            });
        }
    });
}

enableNotificationButton.addEventListener(
    "click",
    enableNotifications
);

// Memuat daftar pengguna dari MySQL
async function loadUsers() {
    try {
        userList.innerHTML = "<p>Memuat pengguna...</p>";

        const response = await fetch("../backend/api/users.php");
        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "Gagal memuat pengguna.");
        }

        const users = result.users || [];

        userList.innerHTML = "";

        const availableUsers = users.filter(user =>
            user.firebase_uid &&
            user.firebase_uid !== currentFirebaseUser.uid
        );

        if (availableUsers.length === 0) {
            userList.innerHTML =
                '<p class="empty-message">Belum ada pengguna lain yang terdaftar.</p>';
            return;
        }

        availableUsers.forEach(user => {
            const button = document.createElement("button");

            button.type = "button";
            button.className = "user-item";
            button.textContent = user.name;

            button.addEventListener("click", () => {
                openConversation(user);
            });

            userList.appendChild(button);
        });

    } catch (error) {
        console.error("Load users:", error);

        userList.innerHTML =
            '<p class="empty-message">Gagal memuat pengguna.</p>';
    }
}

// Membuka percakapan
async function openConversation(user) {
    try {
        if (stopMessageListener) {
            stopMessageListener();
            stopMessageListener = null;
        }

        selectedUser = user;
        currentConversationId = null;

        chatTitle.textContent = user.name;
        messageArea.innerHTML = "<p>Menyiapkan percakapan...</p>";

        const response = await fetch("../backend/api/conversations.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                user_id: user.id
            })
        });

        const result = await response.json();

        if (!response.ok || !result.success || !result.conversation_id) {
            throw new Error(result.message || "Gagal membuka percakapan.");
        }

        currentConversationId = result.conversation_id;

        const participantsRef = ref(
            database,
            `conversations/${currentConversationId}/participants`
        );

        const participantsSnapshot = await get(participantsRef);

        const participants = participantsSnapshot.val();

        if (!participantsSnapshot.exists()) {
            const participantData = {};

            participantData[currentFirebaseUser.uid] = true;
            participantData[user.firebase_uid] = true;

            await set(participantsRef, participantData);

        } else {
            const isCurrentUserParticipant =
                participants[currentFirebaseUser.uid] === true;

            const isSelectedUserParticipant =
                participants[user.firebase_uid] === true;

            if (!isCurrentUserParticipant || !isSelectedUserParticipant) {
                throw new Error(
                    "Data peserta percakapan tidak sesuai. Silakan hubungi administrator."
                );
            }
        }

        listenMessages();

    } catch (error) {
        console.error("Open conversation:", error);

        messageArea.innerHTML =
            "<p>Gagal membuka percakapan. Periksa koneksi dan pengaturan Firebase.</p>";

        showError(error.message);
    }
}

// Mendengarkan pesan secara realtime dari Firebase
function listenMessages() {
    if (stopMessageListener) {
        stopMessageListener();
    }

    const messagesRef = ref(
        database,
        `conversations/${currentConversationId}/messages`
    );

    stopMessageListener = onValue(messagesRef, snapshot => {
        messageArea.innerHTML = "";

        if (!snapshot.exists()) {
            messageArea.innerHTML =
                '<div class="welcome-message"><p>Belum ada pesan. Mulai percakapan sekarang!</p></div>';
            return;
        }

        const messages = snapshot.val();

        Object.entries(messages).forEach(([messageId, message]) => {
            const messageElement = document.createElement("div");

            const isMine =
                message.senderUid === currentFirebaseUser.uid;

            messageElement.className = isMine
                ? "message sent"
                : "message received";

            const sender = document.createElement("strong");

            sender.textContent = isMine
                ? "Anda"
                : (message.senderName || selectedUser.name);

            const content = document.createElement("p");
            content.textContent = message.message || "";

            const time = document.createElement("small");
            time.textContent = formatTime(message.createdAt);

            messageElement.appendChild(sender);
            messageElement.appendChild(content);
            messageElement.appendChild(time);

            messageArea.appendChild(messageElement);
        });

        messageArea.scrollTop = messageArea.scrollHeight;

    }, error => {
        console.error("Firebase message listener:", error);

        showError(
            "Tidak dapat memuat pesan. Periksa aturan keamanan Firebase."
        );
    });
}

// Mengirim pesan ke Firebase dan mengirim notifikasi
messageForm.addEventListener("submit", async event => {
    event.preventDefault();

    const message = messageInput.value.trim();

    if (!message || !currentConversationId || !selectedUser) {
        return;
    }

    if (message.length > 5000) {
        showError("Pesan maksimal 5000 karakter.");
        return;
    }

    try {
        // Simpan pesan ke Firebase
        const messagesRef = ref(
            database,
            `conversations/${currentConversationId}/messages`
        );

        const newMessageRef = push(messagesRef);

        await set(newMessageRef, {
            senderUid: currentFirebaseUser.uid,
            senderName: userData.name,
            message: message,
            createdAt: Date.now()
        });

        messageInput.value = "";
        messageInput.focus();

        // Kirim notifikasi melalui backend PHP
        try {
            const notificationResponse = await fetch(
                "../backend/api/send_notification.php",
                {
                    method: "POST",
                    credentials: "same-origin",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        conversation_id: currentConversationId,
                        message: message
                    })
                }
            );

            const notificationResult =
                await notificationResponse.json();

            console.log(
                "Hasil pengiriman notifikasi:",
                notificationResult
            );

        } catch (notificationError) {
            console.error(
                "Gagal mengirim notifikasi:",
                notificationError
            );
        }

    } catch (error) {
        console.error("Send message:", error);

        showError(
            "Pesan gagal dikirim. Periksa aturan keamanan Firebase."
        );
    }
});

// Logout
logoutButton.addEventListener("click", async () => {
    try {
        await fetch("../backend/api/auth.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                action: "logout"
            })
        });

        await signOut(auth);

        sessionStorage.removeItem("user");
        window.location.href = "login.html";

    } catch (error) {
        console.error("Logout:", error);

        showError("Gagal logout. Silakan coba kembali.");
    }
});

// Memastikan Firebase Auth sudah aktif
onAuthStateChanged(auth, async firebaseUser => {
    if (!firebaseUser) {
        sessionStorage.removeItem("user");
        window.location.href = "login.html";
        return;
    }

    if (!userData || firebaseUser.uid !== userData.firebase_uid) {
        await signOut(auth);

        sessionStorage.removeItem("user");
        window.location.href = "login.html";
        return;
    }

    currentFirebaseUser = firebaseUser;

    if (
        "Notification" in window &&
        Notification.permission === "granted" &&
        await isSupported()
    ) {
        setupForegroundNotifications(getMessaging(app));
    }

    await loadUsers();
});
