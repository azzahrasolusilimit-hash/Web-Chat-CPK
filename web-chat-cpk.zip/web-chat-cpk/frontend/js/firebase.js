
import { initializeApp } from "https://www.gstatic.com/firebasejs/13.3.0/firebase-app.js";

import {
    getAuth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged
} from "https://www.gstatic.com/firebasejs/13.3.0/firebase-auth.js";

import {
    getDatabase,
    ref,
    push,
    set,
    get,
    onValue
} from "https://www.gstatic.com/firebasejs/13.3.0/firebase-database.js";

import {
    getMessaging,
    isSupported,
    getToken,
    onMessage
} from "https://www.gstatic.com/firebasejs/13.3.0/firebase-messaging.js";

const firebaseConfig = {
    apiKey: "AIzaSyAvZh47C5-xz98lyduZ5-IEtENo57CEgHo",
    authDomain: "web-chat-cpk.firebaseapp.com",
    databaseURL: "https://web-chat-cpk-default-rtdb.firebaseio.com",
    projectId: "web-chat-cpk",
    storageBucket: "web-chat-cpk.firebasestorage.app",
    messagingSenderId: "732591709133",
    appId: "1:732591709133:web:7d10b5e84031d16425c284"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);

export {
    app,
    auth,
    database,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    ref,
    push,
    set,
    get,
    onValue,
    getMessaging,
    isSupported,
    getToken,
    onMessage
};
