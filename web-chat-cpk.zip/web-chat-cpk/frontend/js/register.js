import {
    auth,
    createUserWithEmailAndPassword,
    signOut
} from "./firebase.js";

const registerForm = document.getElementById("registerForm");
const messageElement = document.getElementById("message");

registerForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    const submitButton = registerForm.querySelector("button");

    submitButton.disabled = true;
    submitButton.textContent = "Memproses...";
    messageElement.textContent = "";

    let firebaseUser = null;

    try {
        // Membuat akun Firebase
        const credential = await createUserWithEmailAndPassword(
            auth,
            email,
            password
        );

        firebaseUser = credential.user;

        // Mengambil UID dan ID Token Firebase
        const firebaseUid = firebaseUser.uid;
        const idToken = await firebaseUser.getIdToken();

        // Mengirim data ke backend PHP dan MySQL
        const response = await fetch("../backend/api/auth.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                action: "register",
                name: name,
                email: email,
                password: password,
                firebase_uid: firebaseUid,
                id_token: idToken
            })
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "Pendaftaran MySQL gagal.");
        }

        messageElement.textContent =
            "Pendaftaran berhasil! Silakan login.";
        messageElement.style.color = "green";

        registerForm.reset();

        // Keluar dari Firebase setelah registrasi
        await signOut(auth);

    } catch (error) {
        console.error("Registration error:", error);

        if (firebaseUser) {
            try {
                await firebaseUser.delete();
            } catch (deleteError) {
                console.error("Firebase cleanup error:", deleteError);
            }
        }

        let errorMessage = error.message;

        if (error.code === "auth/email-already-in-use") {
            errorMessage = "Email sudah terdaftar di Firebase.";
        } else if (error.code === "auth/weak-password") {
            errorMessage = "Password Firebase minimal 6 karakter.";
        } else if (error.code === "auth/invalid-email") {
            errorMessage = "Format email tidak valid.";
        }

        messageElement.textContent = errorMessage;
        messageElement.style.color = "red";

    } finally {
        submitButton.disabled = false;
        submitButton.textContent = "Daftar";
    }
});
