
import {
    auth,
    signInWithEmailAndPassword,
    signOut
} from "./firebase.js";

const loginForm = document.getElementById("loginForm");
const messageElement = document.getElementById("message");

loginForm.addEventListener("submit", async function (event) {
    event.preventDefault();

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    const submitButton = loginForm.querySelector("button");

    submitButton.disabled = true;
    submitButton.textContent = "Memproses...";
    messageElement.textContent = "";

    try {
        // Login ke Firebase Authentication
        const credential = await signInWithEmailAndPassword(
            auth,
            email,
            password
        );

        const firebaseUser = credential.user;

        // Mengambil UID dan ID Token Firebase
        const firebaseUid = firebaseUser.uid;
        const idToken = await firebaseUser.getIdToken();

        // Mengirim data login ke backend PHP/MySQL
        const response = await fetch("../backend/api/auth.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                action: "login",
                email: email,
                password: password,
                firebase_uid: firebaseUid,
                id_token: idToken
            })
        });

        const result = await response.json();

        if (!response.ok || !result.success) {
            await signOut(auth);
            throw new Error(result.message || "Login backend gagal.");
        }

        // Menyimpan informasi pengguna
        sessionStorage.setItem(
            "user",
            JSON.stringify(result.user)
        );

        messageElement.textContent = "Login berhasil!";
        messageElement.style.color = "green";

        window.location.href = "dashboard.html";

    } catch (error) {
        console.error("Login error:", error);

        // Keluar dari Firebase jika login gagal
        await signOut(auth).catch(function (signOutError) {
            console.error("Firebase sign out error:", signOutError);
        });

        let errorMessage = error.message;

        if (
            error.code === "auth/invalid-credential" ||
            error.code === "auth/user-not-found" ||
            error.code === "auth/wrong-password"
        ) {
            errorMessage = "Email atau password Firebase salah.";
        } else if (error.code === "auth/invalid-email") {
            errorMessage = "Format email tidak valid.";
        } else if (error.code === "auth/too-many-requests") {
            errorMessage = "Terlalu banyak percobaan. Coba lagi nanti.";
        }

        messageElement.textContent = errorMessage;
        messageElement.style.color = "red";

    } finally {
        submitButton.disabled = false;
        submitButton.textContent = "Login";
    }
});
