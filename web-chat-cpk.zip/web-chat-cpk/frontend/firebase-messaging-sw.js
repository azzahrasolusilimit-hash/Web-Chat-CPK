
importScripts('https://www.gstatic.com/firebasejs/13.3.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/13.3.0/firebase-messaging-compat.js');

firebase.initializeApp({
    apiKey: "AIzaSyAvZh47C5-xz98lyduZ5-IEtENo57CEgHo",
    authDomain: "web-chat-cpk.firebaseapp.com",
    databaseURL: "https://web-chat-cpk-default-rtdb.firebaseio.com",
    projectId: "web-chat-cpk",
    storageBucket: "web-chat-cpk.firebasestorage.app",
    messagingSenderId: "732591709133",
    appId: "1:732591709133:web:7d10b5e84031d16425c284"
});

const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
    const notificationTitle =
        payload.notification?.title || 'Web Chat CPK';

    const notificationOptions = {
        body: payload.notification?.body || 'Kamu menerima pesan baru.',
        icon: './favicon.ico'
    };

    self.registration.showNotification(
        notificationTitle,
        notificationOptions
    );
});
