
<?php

session_start();

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['user'])) {
    http_response_code(401);

    echo json_encode([
        'success' => false,
        'message' => 'Silakan login terlebih dahulu.'
    ]);

    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'message' => 'Method tidak diizinkan.'
    ]);

    exit;
}

$conversationId = filter_input(
    INPUT_GET,
    'conversation_id',
    FILTER_VALIDATE_INT
);

$currentUserId = (int) $_SESSION['user']['id'];

if (!$conversationId || $conversationId < 1) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'ID percakapan tidak valid.'
    ]);

    exit;
}

$database = new Database();
$db = $database->connect();

// Pastikan percakapan dimiliki oleh pengguna yang login
$checkConversation = $db->prepare(
    "SELECT id
     FROM conversations
     WHERE id = ?
     AND (user_one = ? OR user_two = ?)"
);

$checkConversation->bind_param(
    "iii",
    $conversationId,
    $currentUserId,
    $currentUserId
);

$checkConversation->execute();

$conversationResult = $checkConversation->get_result();

if ($conversationResult->num_rows === 0) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'message' => 'Anda tidak memiliki akses ke percakapan ini.'
    ]);

    $checkConversation->close();
    $db->close();
    exit;
}

$checkConversation->close();

// Ambil riwayat pesan
$stmt = $db->prepare(
    "SELECT
        messages.id,
        messages.conversation_id,
        messages.sender_id,
        messages.message,
        messages.created_at,
        users.name AS sender_name
     FROM messages
     JOIN users ON messages.sender_id = users.id
     WHERE messages.conversation_id = ?
     ORDER BY messages.created_at ASC, messages.id ASC"
);

$stmt->bind_param("i", $conversationId);
$stmt->execute();

$result = $stmt->get_result();

$messages = [];

while ($message = $result->fetch_assoc()) {
    $messages[] = $message;
}

$stmt->close();
$db->close();

echo json_encode([
    'success' => true,
    'messages' => $messages
]);
