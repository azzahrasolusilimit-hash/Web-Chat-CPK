
<?php

session_start();

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';

// Periksa apakah pengguna sudah login
if (!isset($_SESSION['user'])) {
    http_response_code(401);

    echo json_encode([
        'success' => false,
        'message' => 'Silakan login terlebih dahulu.'
    ]);

    exit;
}

$database = new Database();
$db = $database->connect();

$currentUserId = $_SESSION['user']['id'];

// Ambil pengguna lain, kecuali akun yang sedang login
$stmt = $db->prepare(
    "SELECT id, name, email, firebase_uid
     FROM users
     WHERE id != ?
     ORDER BY name ASC"
);

$stmt->bind_param("i", $currentUserId);
$stmt->execute();

$result = $stmt->get_result();

$users = [];

while ($user = $result->fetch_assoc()) {
    $users[] = $user;
}

$stmt->close();
$db->close();

echo json_encode([
    'success' => true,
    'users' => $users
]);
