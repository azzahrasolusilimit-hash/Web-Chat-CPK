
<?php

session_start();

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['user'])) {
    http_response_code(401);

    echo json_encode([
        'success' => false,
        'message' => 'Silakan login terlebih dahulu.'
    ]);

    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'message' => 'Method tidak diizinkan.'
    ]);

    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$otherUserId = filter_var(
    $data['user_id'] ?? null,
    FILTER_VALIDATE_INT
);

$currentUserId = (int) $_SESSION['user']['id'];

if (!$otherUserId || $otherUserId === $currentUserId) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'Pengguna tujuan tidak valid.'
    ]);

    exit;
}

$database = new Database();
$db = $database->connect();

// Pastikan pengguna tujuan benar-benar ada
$checkUser = $db->prepare(
    "SELECT id FROM users WHERE id = ?"
);

$checkUser->bind_param("i", $otherUserId);
$checkUser->execute();

$userResult = $checkUser->get_result();

if ($userResult->num_rows === 0) {
    http_response_code(404);

    echo json_encode([
        'success' => false,
        'message' => 'Pengguna tidak ditemukan.'
    ]);

    $checkUser->close();
    $db->close();
    exit;
}

$checkUser->close();

// Urutkan ID agar pasangan percakapan selalu konsisten
$userOne = min($currentUserId, $otherUserId);
$userTwo = max($currentUserId, $otherUserId);

// Periksa apakah percakapan sudah tersedia
$checkConversation = $db->prepare(
    "SELECT id FROM conversations
     WHERE user_one = ? AND user_two = ?"
);

$checkConversation->bind_param("ii", $userOne, $userTwo);
$checkConversation->execute();

$result = $checkConversation->get_result();

if ($result->num_rows > 0) {
    $conversation = $result->fetch_assoc();
    $conversationId = (int) $conversation['id'];
} else {
    // Buat percakapan baru
    $insertConversation = $db->prepare(
        "INSERT INTO conversations (user_one, user_two)
         VALUES (?, ?)"
    );

    $insertConversation->bind_param("ii", $userOne, $userTwo);

    if (!$insertConversation->execute()) {
        http_response_code(500);

        echo json_encode([
            'success' => false,
            'message' => 'Gagal membuat percakapan.'
        ]);

        $insertConversation->close();
        $checkConversation->close();
        $db->close();
        exit;
    }

    $conversationId = (int) $db->insert_id;
    $insertConversation->close();
}

$checkConversation->close();
$db->close();

echo json_encode([
    'success' => true,
    'message' => 'Percakapan berhasil dibuka.',
    'conversation_id' => $conversationId
]);
