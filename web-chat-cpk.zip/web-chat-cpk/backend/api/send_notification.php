
<?php

session_start();

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/firebase_messaging.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['user']['id'])) {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'message' => 'Pengguna belum login.'
    ]);
    exit;
}

// Hanya menerima POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'message' => 'Method tidak diizinkan.'
    ]);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$conversationId = (int) ($data['conversation_id'] ?? 0);
$message = trim($data['message'] ?? '');

if ($conversationId <= 0 || $message === '' || strlen($message) > 5000) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => 'Data notifikasi tidak valid.'
    ]);
    exit;
}

try {
    $database = new Database();
    $connection = $database->connect();

    $senderId = (int) $_SESSION['user']['id'];

    // Periksa apakah pengirim merupakan peserta percakapan
    $stmt = $connection->prepare(
        "SELECT user_one, user_two
         FROM conversations
         WHERE id = ?
         AND (user_one = ? OR user_two = ?)"
    );

    $stmt->bind_param("iii", $conversationId, $senderId, $senderId);
    $stmt->execute();

    $conversation = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$conversation) {
        http_response_code(403);
        throw new Exception('Percakapan tidak ditemukan atau akses ditolak.');
    }

    // Tentukan penerima pesan
    $recipientId = (
        (int) $conversation['user_one'] === $senderId
    )
        ? (int) $conversation['user_two']
        : (int) $conversation['user_one'];

    // Ambil token perangkat penerima
    $stmt = $connection->prepare(
        "SELECT token
         FROM fcm_tokens
         WHERE user_id = ?"
    );

    $stmt->bind_param("i", $recipientId);
    $stmt->execute();

    $tokensResult = $stmt->get_result();

    $tokens = [];

    while ($row = $tokensResult->fetch_assoc()) {
        $tokens[] = $row['token'];
    }

    $stmt->close();

    if (empty($tokens)) {
        echo json_encode([
            'success' => true,
            'message' => 'Penerima belum mengaktifkan notifikasi.'
        ]);

        $connection->close();
        exit;
    }

    // Ambil nama pengirim
    $stmt = $connection->prepare(
        "SELECT name FROM users WHERE id = ?"
    );

    $stmt->bind_param("i", $senderId);
    $stmt->execute();

    $sender = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    $senderName = $sender['name'] ?? 'Pesan baru';

    // Ambil OAuth Access Token Firebase
    $accessToken = getFirebaseAccessToken();

    $url = 'https://fcm.googleapis.com/v1/projects/' .
        FIREBASE_PROJECT_ID . '/messages:send';

    $sentCount = 0;
    $errors = [];

    foreach ($tokens as $deviceToken) {
        $payload = [
            'message' => [
                'token' => $deviceToken,
                'notification' => [
                    'title' => $senderName,
                    'body' => mb_substr($message, 0, 100)
                ],
                'webpush' => [
                    'fcm_options' => [
                        'link' => 'http://localhost/web-chat-cpk/frontend/dashboard.html'
                    ]
                ]
            ]
        ];

        $ch = curl_init($url);

        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $accessToken,
                'Content-Type: application/json'
            ],
            CURLOPT_POSTFIELDS => json_encode($payload),
            CURLOPT_TIMEOUT => 30
        ]);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

        if ($response === false) {
            $errors[] = curl_error($ch);
        } elseif ($httpCode >= 200 && $httpCode < 300) {
            $sentCount++;
        } else {
            error_log('FCM HTTP ' . $httpCode . ': ' . $response);
            $errors[] = 'Firebase menolak pengiriman notifikasi.';
        }

        curl_close($ch);
    }

    $connection->close();

    echo json_encode([
        'success' => $sentCount > 0,
        'message' => $sentCount > 0
            ? 'Notifikasi berhasil dikirim.'
            : 'Notifikasi gagal dikirim.',
        'sent' => $sentCount,
        'errors' => $errors
    ]);

} catch (Throwable $e) {
    error_log('Send notification error: ' . $e->getMessage());

    if (!http_response_code() || http_response_code() < 400) {
        http_response_code(500);
    }

    echo json_encode([
        'success' => false,
        'message' => 'Terjadi kesalahan saat mengirim notifikasi.'
    ]);
}
