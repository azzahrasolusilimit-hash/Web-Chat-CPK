
<?php

session_start();

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['user']['id'])) {
    http_response_code(401);

    echo json_encode([
        'success' => false,
        'message' => 'Pengguna belum login.'
    ]);

    exit;
}

// Hanya menerima POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'message' => 'Method tidak diizinkan.'
    ]);

    exit;
}

// Ambil data JSON
$data = json_decode(file_get_contents('php://input'), true);

$token = trim($data['token'] ?? '');

if ($token === '' || strlen($token) > 512) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'FCM Token tidak valid.'
    ]);

    exit;
}

$userId = (int) $_SESSION['user']['id'];

try {
    $database = new Database();
    $connection = $database->connect();

    $stmt = $connection->prepare(
        "INSERT INTO fcm_tokens (user_id, token)
         VALUES (?, ?)
         ON DUPLICATE KEY UPDATE
         user_id = VALUES(user_id),
         updated_at = CURRENT_TIMESTAMP"
    );

    $stmt->bind_param("is", $userId, $token);
    $stmt->execute();

    echo json_encode([
        'success' => true,
        'message' => 'FCM Token berhasil disimpan.'
    ]);

    $stmt->close();
    $connection->close();

} catch (Throwable $e) {
    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Gagal menyimpan FCM Token.'
    ]);
}
