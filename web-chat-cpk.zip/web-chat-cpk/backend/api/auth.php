
<?php

session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'message' => 'Method tidak diizinkan.'
    ]);

    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (!is_array($data)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'Data JSON tidak valid.'
    ]);

    exit;
}

$action = $data['action'] ?? '';

// Proses logout
if ($action === 'logout') {
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();

        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'],
            $params['secure'],
            $params['httponly']
        );
    }

    session_destroy();

    echo json_encode([
        'success' => true,
        'message' => 'Logout berhasil.'
    ]);

    exit;
}

// Proses registrasi dan login
require_once __DIR__ . '/../controllers/AuthController.php';

$auth = new AuthController();

if ($action === 'register') {

    $response = $auth->register($data);

    if ($response['success']) {
        http_response_code(201);
    } else {
        http_response_code(400);
    }

} elseif ($action === 'login') {

    $response = $auth->login($data);

    if ($response['success']) {
        session_regenerate_id(true);
        $_SESSION['user'] = $response['user'];
    } else {
        http_response_code(401);
    }

} else {

    http_response_code(400);

    $response = [
        'success' => false,
        'message' => 'Action tidak dikenal.'
    ];
}

$auth->close();

echo json_encode($response);
