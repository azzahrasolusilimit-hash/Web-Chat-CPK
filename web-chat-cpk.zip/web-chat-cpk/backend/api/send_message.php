
<?php

session_start();

header('Content-Type: application/json');

require_once __DIR__ . '/../config/database.php';

// Pastikan pengguna sudah login
if (!isset($_SESSION['user'])) {
    http_response_code(401);

    echo json_encode([
        'success' => false,
        'message' => 'Silakan login terlebih dahulu.'
    ]);

    exit;
}

// Hanya menerima POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);

    echo json_encode([
        'success' => false,
        'message' => 'Method tidak diizinkan.'
    ]);

    exit;
}

// Ambil data JSON
$data = json_decode(file_get_contents('php://input'), true);

if (!is_array($data)) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'Data JSON tidak valid.'
    ]);

    exit;
}

$conversationId = filter_var(
    $data['conversation_id'] ?? null,
    FILTER_VALIDATE_INT
);

$message = trim($data['message'] ?? '');

$currentUserId = (int) $_SESSION['user']['id'];

// Validasi data pesan
if (!$conversationId || $conversationId < 1) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'ID percakapan tidak valid.'
    ]);

    exit;
}

if ($message === '') {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'Pesan tidak boleh kosong.'
    ]);

    exit;
}

if (strlen($message) > 5000) {
    http_response_code(400);

    echo json_encode([
        'success' => false,
        'message' => 'Pesan maksimal 5000 byte.'
    ]);

    exit;
}

$database = new Database();
$db = $database->connect();

// Pastikan pengguna merupakan anggota percakapan
$checkConversation = $db->prepare(
    "SELECT id
     FROM conversations
     WHERE id = ?
     AND (user_one = ? OR user_two = ?)"
);

$checkConversation->bind_param(
    "iii",
    $conversationId,
    $currentUserId,
    $currentUserId
);

$checkConversation->execute();

$result = $checkConversation->get_result();

if ($result->num_rows === 0) {
    http_response_code(403);

    echo json_encode([
        'success' => false,
        'message' => 'Anda tidak memiliki akses ke percakapan ini.'
    ]);

    $checkConversation->close();
    $db->close();
    exit;
}

$checkConversation->close();

// Simpan pesan ke database
$stmt = $db->prepare(
    "INSERT INTO messages
        (conversation_id, sender_id, message)
     VALUES (?, ?, ?)"
);

$stmt->bind_param(
    "iis",
    $conversationId,
    $currentUserId,
    $message
);

if (!$stmt->execute()) {
    http_response_code(500);

    echo json_encode([
        'success' => false,
        'message' => 'Gagal menyimpan pesan.'
    ]);

    $stmt->close();
    $db->close();
    exit;
}

$messageId = (int) $db->insert_id;

$stmt->close();

// Ambil pesan yang baru disimpan
$getMessage = $db->prepare(
    "SELECT
        messages.id,
        messages.conversation_id,
        messages.sender_id,
        messages.message,
        messages.created_at,
        users.name AS sender_name
     FROM messages
     JOIN users ON messages.sender_id = users.id
     WHERE messages.id = ?"
);

$getMessage->bind_param("i", $messageId);
$getMessage->execute();

$savedMessage = $getMessage->get_result()->fetch_assoc();

$getMessage->close();
$db->close();

echo json_encode([
    'success' => true,
    'message' => 'Pesan berhasil dikirim.',
    'data' => $savedMessage
]);
