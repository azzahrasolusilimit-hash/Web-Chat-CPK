
<?php

require_once dirname(__DIR__, 2) . '/vendor/autoload.php';

use Google\Auth\Credentials\ServiceAccountCredentials;

// Konfigurasi Firebase Cloud Messaging
define('FIREBASE_PROJECT_ID', 'web-chat-cpk');

define(
    'FIREBASE_SERVICE_ACCOUNT_FILE',
    'C:\\firebase-private\\web-chat-cpk-da08b9522dde.json'
);

// Mengambil Google OAuth Access Token
function getFirebaseAccessToken()
{
    $credentials = new ServiceAccountCredentials(
        ['https://www.googleapis.com/auth/firebase.messaging'],
        FIREBASE_SERVICE_ACCOUNT_FILE
    );

    $token = $credentials->fetchAuthToken();

    if (empty($token['access_token'])) {
        throw new Exception('Gagal mendapatkan Firebase Access Token.');
    }

    return $token['access_token'];
}
