
<?php

class Database
{
    private $host = "localhost";
    private $username = "root";
    private $password = "";
    private $database = "web_chat_cpk";

    public $connection;

    public function connect()
    {
        $this->connection = new mysqli(
            $this->host,
            $this->username,
            $this->password,
            $this->database
        );

        if ($this->connection->connect_error) {
            die("Database connection failed: " .
                $this->connection->connect_error);
        }

        $this->connection->set_charset("utf8mb4");

        return $this->connection;
    }
}
