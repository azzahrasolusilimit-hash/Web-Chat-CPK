
<?php

return [
    'project_id' => 'web-chat-cpk',
    'api_key' => 'AIzaSyAvZh47C5-xz98lyduZ5-IEtENo57CEgHo',
];
