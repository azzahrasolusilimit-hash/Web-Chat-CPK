
<?php

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../../vendor/autoload.php';

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class AuthController
{
    private $db;
    private $firebaseConfig;

    public function __construct()
    {
        $database = new Database();
        $this->db = $database->connect();

        $this->firebaseConfig = require __DIR__ . '/../config/firebase.php';
    }

    // Memverifikasi Firebase ID Token
    private function verifyFirebaseToken($idToken, $firebaseUid, $email)
    {
        $logFile = __DIR__ . '/../firebase_debug.log';

        $log = function ($message) use ($logFile) {
            file_put_contents(
                $logFile,
                date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL,
                FILE_APPEND
            );
        };

        if ($idToken === '' || $firebaseUid === '') {
            $log('GAGAL: ID Token atau Firebase UID kosong.');
            return false;
        }

        $url = 'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';

        $certificatesJson = @file_get_contents($url);

        if ($certificatesJson === false) {
            $error = error_get_last();

            $log(
                'GAGAL mengambil sertifikat: ' .
                ($error['message'] ?? 'Tidak diketahui')
            );

            return false;
        }

        $certificates = json_decode($certificatesJson, true);

        if (!is_array($certificates)) {
            $log('GAGAL: Format sertifikat tidak valid.');
            return false;
        }

        try {
            $keys = [];

            foreach ($certificates as $keyId => $certificate) {
                $keys[$keyId] = new Key($certificate, 'RS256');
            }

            $decoded = JWT::decode($idToken, $keys);

            $projectId = $this->firebaseConfig['project_id'];

            $audienceValid =
                ($decoded->aud ?? '') === $projectId;

            $issuerValid =
                ($decoded->iss ?? '') ===
                'https://securetoken.google.com/' . $projectId;

            $uidValid =
                ($decoded->sub ?? '') === $firebaseUid;

            $emailValid =
                strtolower($decoded->email ?? '') === strtolower($email);

            if (
                !$audienceValid ||
                !$issuerValid ||
                !$uidValid ||
                !$emailValid
            ) {
                $log(
                    'GAGAL pencocokan token: ' .
                    'aud=' . ($audienceValid ? 'OK' : 'SALAH') . ', ' .
                    'iss=' . ($issuerValid ? 'OK' : 'SALAH') . ', ' .
                    'uid=' . ($uidValid ? 'OK' : 'SALAH') . ', ' .
                    'email=' . ($emailValid ? 'OK' : 'SALAH')
                );

                return false;
            }

            $log('BERHASIL: Firebase ID Token valid.');

            return true;

        } catch (Throwable $error) {
            $log(
                'GAGAL verifikasi JWT: ' .
                get_class($error) . ' - ' . $error->getMessage()
            );

            return false;
        }
    }

    // Registrasi pengguna
    public function register($data)
    {
        $name = trim($data['name'] ?? '');
        $email = strtolower(trim($data['email'] ?? ''));
        $password = $data['password'] ?? '';
        $firebaseUid = trim($data['firebase_uid'] ?? '');
        $idToken = trim($data['id_token'] ?? '');

        if (
            $name === '' ||
            $email === '' ||
            $password === '' ||
            $firebaseUid === '' ||
            $idToken === ''
        ) {
            return [
                'success' => false,
                'message' => 'Data registrasi tidak lengkap.'
            ];
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return [
                'success' => false,
                'message' => 'Format email tidak valid.'
            ];
        }

        if (strlen($password) < 8) {
            return [
                'success' => false,
                'message' => 'Password minimal 8 karakter.'
            ];
        }

        if (!$this->verifyFirebaseToken($idToken, $firebaseUid, $email)) {
            return [
                'success' => false,
                'message' => 'Verifikasi identitas Firebase gagal.'
            ];
        }

        $check = $this->db->prepare(
            "SELECT id FROM users WHERE email = ? OR firebase_uid = ?"
        );

        $check->bind_param("ss", $email, $firebaseUid);
        $check->execute();

        if ($check->get_result()->num_rows > 0) {
            $check->close();

            return [
                'success' => false,
                'message' => 'Email sudah terdaftar di sistem.'
            ];
        }

        $check->close();

        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $this->db->prepare(
            "INSERT INTO users (name, email, firebase_uid, password)
             VALUES (?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "ssss",
            $name,
            $email,
            $firebaseUid,
            $hashedPassword
        );

        if ($stmt->execute()) {
            $userId = $stmt->insert_id;
            $stmt->close();

            return [
                'success' => true,
                'message' => 'Registrasi berhasil.',
                'user' => [
                    'id' => $userId,
                    'name' => $name,
                    'email' => $email,
                    'firebase_uid' => $firebaseUid
                ]
            ];
        }

        $stmt->close();

        return [
            'success' => false,
            'message' => 'Registrasi gagal.'
        ];
    }

    // Login pengguna
    public function login($data)
    {
        $email = strtolower(trim($data['email'] ?? ''));
        $password = $data['password'] ?? '';
        $firebaseUid = trim($data['firebase_uid'] ?? '');
        $idToken = trim($data['id_token'] ?? '');

        if (
            $email === '' ||
            $password === '' ||
            $firebaseUid === '' ||
            $idToken === ''
        ) {
            return [
                'success' => false,
                'message' => 'Data login tidak lengkap.'
            ];
        }

        // Verifikasi identitas melalui Firebase
        if (!$this->verifyFirebaseToken($idToken, $firebaseUid, $email)) {
            return [
                'success' => false,
                'message' => 'Verifikasi identitas Firebase gagal.'
            ];
        }

        // Mencari akun di MySQL
        $stmt = $this->db->prepare(
            "SELECT id, name, email, password, firebase_uid
             FROM users
             WHERE email = ?"
        );

        $stmt->bind_param("s", $email);
        $stmt->execute();

        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        $stmt->close();

        if (!$user) {
            return [
                'success' => false,
                'message' => 'Akun belum terdaftar di sistem.'
            ];
        }

        // Memastikan Firebase UID sesuai
        if (
            !empty($user['firebase_uid']) &&
            $user['firebase_uid'] !== $firebaseUid
        ) {
            return [
                'success' => false,
                'message' => 'Identitas Firebase tidak cocok.'
            ];
        }

        // Sinkronisasi UID dan password hash ke MySQL
        // Password telah diverifikasi oleh Firebase sebelumnya.
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $update = $this->db->prepare(
            "UPDATE users
             SET firebase_uid = ?, password = ?
             WHERE id = ?"
        );

        $update->bind_param(
            "ssi",
            $firebaseUid,
            $hashedPassword,
            $user['id']
        );

        if (!$update->execute()) {
            $update->close();

            return [
                'success' => false,
                'message' => 'Gagal menyinkronkan data akun.'
            ];
        }

        $update->close();

        return [
            'success' => true,
            'message' => 'Login berhasil.',
            'user' => [
                'id' => $user['id'],
                'name' => $user['name'],
                'email' => $user['email'],
                'firebase_uid' => $firebaseUid
            ]
        ];
    }

    // Menutup koneksi database
    public function close()
    {
        if ($this->db) {
            $this->db->close();
        }
    }
}
