
<?php

require_once __DIR__ . '/backend/config/database.php';

$database = new Database();
$db = $database->connect();

if ($db) {
    echo "Database connected successfully!";
}

$db->close();
